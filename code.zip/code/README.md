build 为压缩版本
public 为原始代码
