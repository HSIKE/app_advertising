buid 文件夹下是压缩过的代码
public 文件夹下是原始代码
